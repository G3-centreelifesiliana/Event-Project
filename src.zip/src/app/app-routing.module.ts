import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EventFormComponent } from './event-form/event-form.component';
import { FilmComponent } from './film/film.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ReservationComponent } from './reservation/reservation.component';
import { SignupComponent } from './signup/signup.component';
import { SpectacleComponent } from './spectacle/spectacle.component';
import { SportComponent } from './sport/sport.component';

const routes: Routes = [
  { path: 'signup', component: SignupComponent },
  { path: 'login', component: LoginComponent },
  { path: 'home', component: HomeComponent },
  { path: 'category/Sport', component: SportComponent },
  { path: 'category/Film', component: FilmComponent },
  { path: 'category/Spectacle', component: SpectacleComponent },

  { path: 'nouveau', component: EventFormComponent},
  { path: 'reservation', component: ReservationComponent},

  { path: '', redirectTo: '/', pathMatch: 'full' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
