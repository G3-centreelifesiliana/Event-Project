import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CarouselComponent } from './carousel/carousel.component';
import { CategoryComponent } from './category/category.component';
import { EventFormComponent } from './event-form/event-form.component';
import { EventListComponent } from './event-list/event-list.component';
import { EventdeatilsComponent } from './eventdeatils/eventdeatils.component';
import { FeedbackListComponent } from './feedback-list/feedback-list.component';
import { FilmComponent } from './film/film.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ReservationComponent } from './reservation/reservation.component';
import { BASE_URL } from './shared/BaseURL';
import { SignupComponent } from './signup/signup.component';
import { SpectacleComponent } from './spectacle/spectacle.component';
import { SportComponent } from './sport/sport.component';
import { UserComponent } from './user/user.component';

@NgModule({
  declarations: [
    AppComponent,
    EventListComponent,
    UserComponent,
    ReservationComponent,
    CategoryComponent,
    HomeComponent,
    RegisterComponent,
    LoginComponent,
    EventFormComponent,
    CarouselComponent,
    FeedbackListComponent,
    FilmComponent,
    SportComponent,
    SpectacleComponent,
    EventdeatilsComponent,
    SignupComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    ReactiveFormsModule,
    NgbModule,
    HttpClientModule

  ],
  providers: [{ provide: 'BaseURL', useValue: BASE_URL}],
  bootstrap: [AppComponent]
})
export class AppModule { }
