export interface Category{
    id: number;
    name: string;
    type: 'SPECTACLE' | 'SPORT' | 'FILM';
    
  }
