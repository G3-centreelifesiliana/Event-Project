import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Event } from '../event-list/Event';
import { CategoryService } from '../services/category.service';
import { Category } from './Category';
@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  categories: Category[] = [];
  selectedCategory: Category = { id: null, name: '', type: 'SPECTACLE' };
  eventsByCategory: Event[] = []; 
  constructor(private categoryService: CategoryService, private router: Router) { }

  ngOnInit(): void {
    this.loadCategories();
  }

  loadCategories(): void {
    this.categoryService.getAllCategories().subscribe(categories => {
      this.categories = categories;
    });
  }

  loadEventsByCategory(categoryId: number): void {
    this.categoryService.getEventsByCategory(categoryId).subscribe(events => {
     // this.eventsByCategory = events;
    });
  }

  navigateToCategory(category: string): void {
    this.router.navigate(['/events/category', category]);
  }

  editCategory(category: Category): void {
    this.selectedCategory = { ...category };
  }

  saveCategory(): void {
    if (this.selectedCategory.id) {
      this.categoryService.updateCategory(this.selectedCategory.id, this.selectedCategory).subscribe(() => {
        this.loadCategories();
        this.resetForm();
      });
    } else {
      this.categoryService.createCategory(this.selectedCategory).subscribe(() => {
        this.loadCategories();
        this.resetForm();
      });
    }
  }

  deleteCategory(id: number): void {
    this.categoryService.deleteCategory(id).subscribe(() => {
      this.loadCategories();
    });
  }

  resetForm(): void {
    this.selectedCategory = { id: null, name: '', type: 'SPECTACLE' };
  }
}

