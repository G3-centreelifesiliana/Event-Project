import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Category } from '../category/Category';
import { EventService } from '../services/event.service';

@Component({
  selector: 'app-event-form',
  templateUrl: './event-form.component.html',
  styleUrls: ['./event-form.component.css']
})
export class EventFormComponent implements OnInit {
  eventForm: FormGroup;
  eventId: number;
  categories: Category[] = [
    { id: 1, name: 'Spectacle', type: 'SPECTACLE' },
    { id: 2, name: 'Sport', type: 'SPORT' },
    { id: 3, name: 'Festival', type: 'FILM' }
  ];
  constructor(
    private fb: FormBuilder,
    private eventService: EventService,
    private route: ActivatedRoute,
    private router: Router
  ) { }
  ngOnInit(): void {
    this.eventId = +this.route.snapshot.paramMap.get('id');
    this.createForm();
    if (this.eventId) {
      this.loadEvent();
    }
  }

  createForm(): void {
    this.eventForm = this.fb.group({
      name: ['', Validators.required],
      date: ['', Validators.required],
      description: ['', Validators.required],
      location: ['', Validators.required],
      image: [''],
      prix: ['', [Validators.required, Validators.pattern('^[0-100]*dt')]],
      category: ['', Validators.required]
    });
  }

  loadEvent(): void {
    this.eventService.getEventById(this.eventId).subscribe(
      data => {
        this.eventForm.patchValue(data);
      },
      error => {
        console.error('Error loading event', error);
      }
    );
  }

  saveEvent(): void {
    if (this.eventForm.valid) {
      const event = this.eventForm.value;
      if (this.eventId) {
        this.eventService.updateEvent(this.eventId, event).subscribe(
          () => this.router.navigate(['/events']),
          error => console.error('Error updating event', error)
        );
      } else {
        this.eventService.createEvent(event).subscribe(
          () => this.router.navigate(['/events']),
          error => console.error('Error creating event', error)
        );
      }
    }
  }


}
