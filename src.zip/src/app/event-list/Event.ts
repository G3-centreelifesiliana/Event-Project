import { Category } from "../category/Category";
import { Feedback } from "../feedback-list/Feedback";
import { Reservation } from "../reservation/Reservation";

export interface Event {
    id: number; 
    name: string;
    date: Date;
    description: string;
    location: string;
    image: string;
    prix: number;
    category: Category;
    reservetion:Reservation[];
    feedback?: Feedback;
  }