import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EventService } from '../services/event.service';
import { ReservationService } from '../services/reservation.service';
import { Event } from './Event';
@Component({
  selector: 'app-event-list',
  templateUrl: './event-list.component.html',
  styleUrls: ['./event-list.component.css']
})
export class EventListComponent implements OnInit {

  events: Event[] = [];
  category: string | null = null;
  filteredEvents: Event[] = [];

  constructor(
    private eventService: EventService, 
    private reservationService: ReservationService,
    private route: ActivatedRoute,
    private router: Router 
  )  { this.filteredEvents = this.events}

  filterEvents(category: string) {
    this.category = category;
    this.filteredEvents = this.events.filter(event => event.category.type === category);
  }
  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.category = params['category'];
      this.loadEvents();
    });
  }

  loadEvents(): void {
    if (this.category) {
      this.eventService.getEventsByCategory(this.category).subscribe(
        data => this.events = data,
        error => console.error('Error loading events', error)
      );
    } else {
      this.eventService.getAllEvents().subscribe(
        data => this.events = data,
        error => console.error('Error loading events', error)
      );
    }
  }

  deleteEvent(id: number): void {
    this.eventService.deleteEvent(id).subscribe(() => {
      this.loadEvents(); 
    });
  }

  reservation(eventId: number): void {
    this.reservationService.createReservation(eventId).subscribe(
      () => this.router.navigate(['/reservations']),
      error => console.error('Error creating reservation', error)
    );
  }
}
