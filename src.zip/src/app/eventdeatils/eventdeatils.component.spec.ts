import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EventdeatilsComponent } from './eventdeatils.component';

describe('EventdeatilsComponent', () => {
  let component: EventdeatilsComponent;
  let fixture: ComponentFixture<EventdeatilsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EventdeatilsComponent]
    });
    fixture = TestBed.createComponent(EventdeatilsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
