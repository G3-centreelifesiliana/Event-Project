import { Component } from '@angular/core';

@Component({
  selector: 'app-eventdeatils',
  templateUrl: './eventdeatils.component.html',
  styleUrls: ['./eventdeatils.component.css']
})
export class EventdeatilsComponent {

}
