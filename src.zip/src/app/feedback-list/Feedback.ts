import { Event } from "../event-list/Event";
import { User } from "../user/User";
export interface Feedback {
    id: number;
    name: string;
    feedback: string;
    event: Event; 
    user: User; 
  }