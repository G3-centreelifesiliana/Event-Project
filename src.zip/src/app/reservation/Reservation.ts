import { Event } from "../event-list/Event";
import { User } from "../user/User";

export interface Reservation{
    id : number ;
    user:User;
    event:Event;
}