export interface AuthResponseData {
    id : number,
    email : string,
    roles : string[],
  }