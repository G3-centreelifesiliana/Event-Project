export interface RegisterUser {
   
    firstname: string;
    lastname: string;
    email: string;
    password: string;
    role: string;
  }