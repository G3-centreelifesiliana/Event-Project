export interface Role {
    name: string,
    permissions: string[]
  }