import { Role } from "./Role";

export interface User{
    id:number;
    username:String;
    password:String;
    email:string;
    role:Role;
    token?: string;


}