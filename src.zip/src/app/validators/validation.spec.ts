import { Validation } from './validation';

describe('Validation', () => {
  it('should create an instance', () => {
    expect(new Validation()).toBeTruthy();
  });
});
